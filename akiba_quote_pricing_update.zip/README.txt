Akiba Quote Tool – Pricing Update
---------------------------------
- script.js : Full app logic with generated products pricing map and tiered pricing.
- products_pricing.js : Extracted products object in case you want to import separately.

Tier policy applied:
  Tier 1 up to 5,000: price = base from pricebook
  Tier 2 up to 10,000: price = Tier1 * (1 - 0.0725)
  Tier 3 up to 25,000: price = Tier2 * (1 - 0.0725)
  Tier 4 up to 50,000: price = Tier3 * (1 - 0.0725)
  Tier 5 up to Infinity: price = Tier4 * (1 - 0.0725)

Rounding: 6 decimals in JSON, displayed with 2 decimals in UI.

Missing endpoint requiring a base price:
  - /api/v4/idverification